package com.culture.demo.mapper;

public interface TeacherMapper {

}
